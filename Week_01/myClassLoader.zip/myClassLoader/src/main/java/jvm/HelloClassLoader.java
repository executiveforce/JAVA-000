package jvm;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class HelloClassLoader extends ClassLoader{

    String path;
    String className;

    public HelloClassLoader(String path, String name){
        this.path = path;
        this.className = name;
    }


    public static void main(String[] args) throws IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {
        Class clazz = (Class) new HelloClassLoader("/Users/Billy/Downloads/myClassLoader/file/","Hello").
                findClass("Hello");
        Object o = clazz.newInstance();
        Method method = clazz.getDeclaredMethod("hello",null);
        method.invoke(o);


    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException{

        byte[] bytess = loadClassData(name);
        for (int i = 0; i < bytess.length; i++) {
            bytess[i] = (byte) (255 - bytess[i]);
        }
        return defineClass(name, bytess, 0, bytess.length);
    }

    private byte[] loadClassData(String name) {
        String fullName = path+name+".xlass";
        InputStream in = null;
        ByteArrayOutputStream out = null;
        try {
            in= new FileInputStream(new File(fullName));
            out = new ByteArrayOutputStream();
            int i=0;
            while ((i=in.read())!=-1){
                out.write(i);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(in != null){
                try{
                    in.close();
                }catch(IOException e){
                    e.printStackTrace();

                }
            }
        }

        return out.toByteArray();
    }}
